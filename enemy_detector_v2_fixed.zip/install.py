#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Auto Installer for Enemy Detector
Automatyczny instalator wszystkich wymagań
"""

import subprocess
import sys
import os
import time

def print_header():
    """Wyświetla nagłówek"""
    print("\n" + "="*60)
    print("   🔧 ENEMY DETECTOR - AUTOMATYCZNA INSTALACJA")
    print("="*60)

def check_python_version():
    """Sprawdza wersję Pythona"""
    print("\n📌 Sprawdzanie wersji Python...")
    version = sys.version_info
    print(f"   Znaleziono: Python {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 6):
        print("\n❌ BŁĄD: Wymagany Python 3.6 lub nowszy!")
        print("   Pobierz z: https://www.python.org/downloads/")
        return False
    
    print("   ✅ Wersja OK!")
    return True

def upgrade_pip():
    """Aktualizuje pip"""
    print("\n📌 Aktualizacja pip...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
                            stdout=subprocess.DEVNULL)
        print("   ✅ Pip zaktualizowany!")
    except:
        print("   ⚠️ Nie udało się zaktualizować pip (kontynuuję)")

def install_package(package_name):
    """Instaluje pojedynczy pakiet"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
        return True
    except:
        return False

def main():
    """Główna funkcja instalatora"""
    print_header()
    
    # Sprawdzenie Pythona
    if not check_python_version():
        input("\nNaciśnij Enter aby zakończyć...")
        return 1
    
    # Aktualizacja pip
    upgrade_pip()
    
    # Lista pakietów
    packages = {
        'numpy': 'Biblioteka obliczeń numerycznych',
        'opencv-python': 'Przetwarzanie obrazu',
        'mss': 'Przechwytywanie ekranu',
        'Pillow': 'Obsługa obrazów'
    }
    
    # Pakiety Windows
    if sys.platform == 'win32':
        packages.update({
            'pywin32': 'Integracja z Windows',
            'keyboard': 'Obsługa klawiatury'
        })
    
    # Instalacja pakietów
    print("\n📦 INSTALACJA PAKIETÓW:")
    print("-" * 40)
    
    failed = []
    for i, (package, description) in enumerate(packages.items(), 1):
        print(f"\n[{i}/{len(packages)}] Instalowanie: {package}")
        print(f"    {description}")
        print("    ", end="")
        
        # Animacja ładowania
        for j in range(20):
            print("█", end="", flush=True)
            time.sleep(0.05)
        
        if install_package(package):
            print(" ✅")
        else:
            print(" ❌")
            failed.append(package)
    
    # Podsumowanie
    print("\n" + "="*60)
    print("   📊 PODSUMOWANIE INSTALACJI")
    print("="*60)
    
    if not failed:
        print("\n✅ SUKCES! Wszystkie pakiety zainstalowane!")
        print("\n🎮 Możesz teraz uruchomić program:")
        print("   • Windows: Kliknij START.bat")
        print("   • Lub: python launcher.py")
    else:
        print(f"\n⚠️ Nie udało się zainstalować: {', '.join(failed)}")
        print("\nSpróbuj ręcznie:")
        for pkg in failed:
            print(f"   pip install {pkg}")
    
    print("\n" + "="*60)
    input("\nNaciśnij Enter aby zakończyć...")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\n❌ Instalacja przerwana przez użytkownika")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Błąd krytyczny: {e}")
        input("\nNaciśnij Enter aby zakończyć...")
        sys.exit(1)
