#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Simple Config GUI for Enemy Detector
Prosty i przyjazny interfejs konfiguracji
"""

import sys
import os
import json
import subprocess

# Automatyczna instalacja tkinter jeśli brakuje
try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except ImportError:
    print("[INFO] Instalowanie tkinter...")
    if sys.platform == 'win32':
        print("[ERROR] Tkinter powinien być zainstalowany z Python!")
        print("Proszę zainstalować Python ze strony python.org")
        input("Naciśnij Enter...")
        sys.exit(1)

class SimpleConfigGUI:
    """Prosty interfejs konfiguracji"""
    
    def __init__(self):
        # Utworzenie głównego okna
        self.root = tk.Tk()
        self.root.title("🎮 Enemy Detector - Konfiguracja")
        self.root.geometry("600x700")
        self.root.resizable(False, False)
        
        # Ustawienie ikony i koloru tła
        self.root.configure(bg='#2b2b2b')
        
        # Domyślna konfiguracja
        self.config = self.load_config()
        
        # Tworzenie interfejsu
        self.create_widgets()
        
        # Centrowanie okna
        self.center_window()
    
    def center_window(self):
        """Centruje okno na ekranie"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def load_config(self):
        """Ładuje konfigurację z pliku"""
        default_config = {
            'sensitivity': 0.75,
            'confidence_threshold': 0.6,
            'smooth_factor': 0.3,
            'fov_x': 120,
            'fov_y': 120,
            'aim_speed': 1.5,
            'prediction_factor': 0.2,
            'color_tolerance': 40,
            'head_offset': 0.15,
            'distance_weight': 0.7,
            'movement_threshold': 2.0
        }
        
        if os.path.exists('detector_config.json'):
            try:
                with open('detector_config.json', 'r') as f:
                    loaded = json.load(f)
                    # Aktualizuj tylko istniejące klucze
                    for key in default_config:
                        if key in loaded:
                            default_config[key] = loaded[key]
            except:
                pass
        
        return default_config
    
    def create_widgets(self):
        """Tworzy elementy interfejsu"""
        # Styl
        style = ttk.Style()
        style.theme_use('clam')
        
        # Nagłówek
        header_frame = tk.Frame(self.root, bg='#1e1e1e', height=80)
        header_frame.pack(fill='x', padx=0, pady=0)
        header_frame.pack_propagate(False)
        
        title = tk.Label(header_frame, text="⚙️ KONFIGURACJA DETEKTORA",
                        font=('Arial', 18, 'bold'), fg='white', bg='#1e1e1e')
        title.pack(pady=25)
        
        # Główna ramka
        main_frame = tk.Frame(self.root, bg='#2b2b2b')
        main_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Profile - prostsze
        profile_frame = tk.LabelFrame(main_frame, text=" 📋 Szybkie Profile ",
                                    font=('Arial', 10, 'bold'), fg='white', bg='#2b2b2b')
        profile_frame.pack(fill='x', pady=(0, 15))
        
        profiles = [
            ("🎯 Precyzyjny", self.load_precise_profile),
            ("⚖️ Zbalansowany", self.load_balanced_profile),
            ("⚔️ Agresywny", self.load_aggressive_profile)
        ]
        
        for text, command in profiles:
            btn = tk.Button(profile_frame, text=text, command=command,
                          bg='#404040', fg='white', font=('Arial', 9),
                          width=15, relief='flat', cursor='hand2')
            btn.pack(side='left', padx=5, pady=10)
        
        # Ustawienia podstawowe
        basic_frame = tk.LabelFrame(main_frame, text=" 🎮 Podstawowe Ustawienia ",
                                  font=('Arial', 10, 'bold'), fg='white', bg='#2b2b2b')
        basic_frame.pack(fill='x', pady=(0, 15))
        
        # Czułość
        self.create_simple_slider(basic_frame, "Czułość detekcji:", 'sensitivity',
                                0.1, 1.0, "Jak łatwo wykrywa przeciwników")
        
        # FOV
        self.create_simple_slider(basic_frame, "Zasięg widzenia (FOV):", 'fov_x',
                                50, 300, "Obszar skanowania ekranu", is_int=True)
        
        # Szybkość celowania
        self.create_simple_slider(basic_frame, "Szybkość celowania:", 'aim_speed',
                                0.5, 3.0, "Jak szybko przesuwa celownik")
        
        # Ustawienia zaawansowane (ukryte domyślnie)
        self.advanced_visible = False
        
        toggle_btn = tk.Button(main_frame, text="⚙️ Pokaż zaawansowane",
                             command=self.toggle_advanced,
                             bg='#404040', fg='white', font=('Arial', 9),
                             relief='flat', cursor='hand2')
        toggle_btn.pack(pady=10)
        
        self.advanced_frame = tk.LabelFrame(main_frame, text=" 🔧 Zaawansowane ",
                                          font=('Arial', 10, 'bold'), 
                                          fg='white', bg='#2b2b2b')
        
        # Zaawansowane slidery (początkowo ukryte)
        self.create_simple_slider(self.advanced_frame, "Próg pewności:", 
                                'confidence_threshold', 0.1, 1.0,
                                "Minimalna pewność detekcji")
        self.create_simple_slider(self.advanced_frame, "Płynność ruchu:", 
                                'smooth_factor', 0.1, 0.8,
                                "Jak płynnie porusza się celownik")
        self.create_simple_slider(self.advanced_frame, "Przewidywanie:", 
                                'prediction_factor', 0.0, 0.5,
                                "Przewidywanie ruchu celu")
        
        # Przyciski akcji
        button_frame = tk.Frame(main_frame, bg='#2b2b2b')
        button_frame.pack(side='bottom', fill='x', pady=(20, 0))
        
        # Duże, czytelne przyciski
        buttons = [
            ("💾 ZAPISZ", self.save_config, '#4CAF50'),
            ("🚀 URUCHOM DETEKTOR", self.run_detector, '#2196F3'),
            ("❌ ZAMKNIJ", self.root.quit, '#f44336')
        ]
        
        for text, command, color in buttons:
            btn = tk.Button(button_frame, text=text, command=command,
                          bg=color, fg='white', font=('Arial', 11, 'bold'),
                          height=2, width=18, relief='flat', cursor='hand2')
            btn.pack(side='left', padx=5, expand=True, fill='x')
        
        # Status bar
        self.status = tk.Label(self.root, text="Gotowy", 
                             bg='#1e1e1e', fg='#4CAF50', 
                             font=('Arial', 9), anchor='w')
        self.status.pack(side='bottom', fill='x', padx=10, pady=5)
    
    def create_simple_slider(self, parent, label_text, config_key, min_val, max_val, 
                           help_text="", is_int=False):
        """Tworzy prosty slider"""
        frame = tk.Frame(parent, bg='#2b2b2b')
        frame.pack(fill='x', padx=15, pady=8)
        
        # Etykieta
        label = tk.Label(frame, text=label_text, fg='white', bg='#2b2b2b',
                        font=('Arial', 10))
        label.pack(anchor='w')
        
        if help_text:
            help_label = tk.Label(frame, text=help_text, fg='#888888', bg='#2b2b2b',
                                font=('Arial', 8))
            help_label.pack(anchor='w')
        
        # Frame dla slidera i wartości
        slider_frame = tk.Frame(frame, bg='#2b2b2b')
        slider_frame.pack(fill='x', pady=5)
        
        # Wartość
        value_var = tk.StringVar()
        if is_int:
            value_var.set(str(int(self.config[config_key])))
        else:
            value_var.set(f"{self.config[config_key]:.2f}")
        
        value_label = tk.Label(slider_frame, textvariable=value_var,
                              fg='#4CAF50', bg='#2b2b2b',
                              font=('Arial', 10, 'bold'), width=6)
        value_label.pack(side='right', padx=5)
        
        # Slider
        if is_int:
            var = tk.IntVar(value=int(self.config[config_key]))
        else:
            var = tk.DoubleVar(value=self.config[config_key])
        
        def update_value(val):
            if is_int:
                value_var.set(str(int(float(val))))
                self.config[config_key] = int(float(val))
            else:
                value_var.set(f"{float(val):.2f}")
                self.config[config_key] = float(val)
        
        slider = tk.Scale(slider_frame, from_=min_val, to=max_val,
                        orient='horizontal', variable=var,
                        command=update_value, showvalue=False,
                        bg='#404040', fg='white', 
                        troughcolor='#606060',
                        activebackground='#4CAF50',
                        highlightthickness=0)
        slider.pack(side='left', fill='x', expand=True)
        
        # Zapisz referencje
        setattr(self, f"{config_key}_var", var)
        setattr(self, f"{config_key}_label", value_label)
    
    def toggle_advanced(self):
        """Pokazuje/ukrywa zaawansowane opcje"""
        if self.advanced_visible:
            self.advanced_frame.pack_forget()
            self.advanced_visible = False
        else:
            self.advanced_frame.pack(fill='x', pady=(0, 15))
            self.advanced_visible = True
    
    def load_precise_profile(self):
        """Ładuje profil precyzyjny"""
        self.config['sensitivity'] = 0.9
        self.config['aim_speed'] = 1.0
        self.config['confidence_threshold'] = 0.7
        self.update_sliders()
        self.status.config(text="✓ Załadowano profil: Precyzyjny", fg='#4CAF50')
    
    def load_balanced_profile(self):
        """Ładuje profil zbalansowany"""
        self.config['sensitivity'] = 0.75
        self.config['aim_speed'] = 1.5
        self.config['confidence_threshold'] = 0.6
        self.update_sliders()
        self.status.config(text="✓ Załadowano profil: Zbalansowany", fg='#4CAF50')
    
    def load_aggressive_profile(self):
        """Ładuje profil agresywny"""
        self.config['sensitivity'] = 0.6
        self.config['aim_speed'] = 2.0
        self.config['confidence_threshold'] = 0.4
        self.update_sliders()
        self.status.config(text="✓ Załadowano profil: Agresywny", fg='#4CAF50')
    
    def update_sliders(self):
        """Aktualizuje wartości sliderów"""
        for key in self.config:
            if hasattr(self, f"{key}_var"):
                var = getattr(self, f"{key}_var")
                var.set(self.config[key])
    
    def save_config(self):
        """Zapisuje konfigurację"""
        try:
            with open('detector_config.json', 'w') as f:
                json.dump(self.config, f, indent=2)
            
            self.status.config(text="✓ Konfiguracja zapisana!", fg='#4CAF50')
            
            # Pokazanie komunikatu
            popup = tk.Toplevel(self.root)
            popup.title("Sukces")
            popup.geometry("300x100")
            popup.configure(bg='#2b2b2b')
            
            msg = tk.Label(popup, text="✓ Konfiguracja została zapisana!",
                         font=('Arial', 12), fg='#4CAF50', bg='#2b2b2b')
            msg.pack(pady=20)
            
            tk.Button(popup, text="OK", command=popup.destroy,
                    bg='#4CAF50', fg='white', width=10).pack()
            
            # Centrowanie popup
            popup.transient(self.root)
            popup.grab_set()
            self.root.wait_window(popup)
            
        except Exception as e:
            self.status.config(text=f"✗ Błąd zapisu: {str(e)}", fg='#f44336')
            messagebox.showerror("Błąd", f"Nie udało się zapisać:\n{str(e)}")
    
    def run_detector(self):
        """Uruchamia detektor"""
        self.save_config()  # Najpierw zapisz
        
        if not os.path.exists('enhanced_detector.py'):
            messagebox.showerror("Błąd", "Nie znaleziono pliku enhanced_detector.py!")
            return
        
        try:
            # Uruchom w nowym oknie
            if sys.platform == 'win32':
                subprocess.Popen(['python', 'enhanced_detector.py'], 
                               creationflags=subprocess.CREATE_NEW_CONSOLE)
            else:
                subprocess.Popen(['python', 'enhanced_detector.py'])
            
            self.status.config(text="✓ Detektor uruchomiony!", fg='#4CAF50')
            
        except Exception as e:
            self.status.config(text=f"✗ Błąd: {str(e)}", fg='#f44336')
            messagebox.showerror("Błąd", f"Nie udało się uruchomić:\n{str(e)}")
    
    def run(self):
        """Uruchamia GUI"""
        try:
            self.root.mainloop()
        except Exception as e:
            print(f"[ERROR] Błąd GUI: {e}")
            input("Naciśnij Enter aby zakończyć...")

def main():
    """Funkcja główna"""
    try:
        print("\n" + "="*50)
        print("   ENEMY DETECTOR - KONFIGURACJA")
        print("="*50)
        print("\n[INFO] Uruchamianie interfejsu graficznego...")
        
        app = SimpleConfigGUI()
        app.run()
        
    except Exception as e:
        print(f"\n[ERROR] Wystąpił błąd: {e}")
        print("\n[INFO] Spróbuj uruchomić program jako administrator")
        input("\nNaciśnij Enter aby zakończyć...")

if __name__ == "__main__":
    main()
