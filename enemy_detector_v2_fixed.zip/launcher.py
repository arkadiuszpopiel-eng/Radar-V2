#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Enemy Detector Launcher - Simple Version
Prosty launcher dla użytkowników amatorów
"""

import os
import sys
import subprocess
import time

def clear_screen():
    """Czyści ekran"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    """Wyświetla nagłówek"""
    print("\n" + "="*60)
    print("   🎮 ENEMY DETECTOR V2.0 - MENU GŁÓWNE 🎮")
    print("="*60)

def check_python():
    """Sprawdza wersję Pythona"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 6):
        print("\n⚠️  UWAGA: Wymagany Python 3.6 lub nowszy!")
        print(f"   Twoja wersja: {sys.version}")
        return False
    return True

def install_requirements():
    """Instaluje wymagane pakiety"""
    print("\n📦 INSTALACJA PAKIETÓW")
    print("-" * 40)
    
    packages = [
        'opencv-python',
        'numpy', 
        'mss',
        'Pillow'
    ]
    
    if sys.platform == 'win32':
        packages.extend(['pywin32', 'keyboard'])
    
    print("Instalowanie pakietów...")
    for package in packages:
        print(f"  - {package}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package],
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
        except:
            print(f"    ⚠️ Nie udało się zainstalować {package}")
    
    print("\n✅ Instalacja zakończona!")
    input("\nNaciśnij Enter aby kontynuować...")

def run_config():
    """Uruchamia konfigurację"""
    clear_screen()
    print("\n⚙️  URUCHAMIANIE KONFIGURACJI...")
    print("-" * 40)
    
    if not os.path.exists('config_gui.py'):
        print("\n❌ Błąd: Brak pliku config_gui.py!")
        input("\nNaciśnij Enter aby wrócić...")
        return
    
    try:
        subprocess.run([sys.executable, 'config_gui.py'])
    except Exception as e:
        print(f"\n❌ Błąd: {e}")
        input("\nNaciśnij Enter aby wrócić...")

def run_detector():
    """Uruchamia detektor"""
    clear_screen()
    print("\n🚀 URUCHAMIANIE DETEKTORA...")
    print("-" * 40)
    
    if not os.path.exists('enhanced_detector.py'):
        print("\n❌ Błąd: Brak pliku enhanced_detector.py!")
        input("\nNaciśnij Enter aby wrócić...")
        return
    
    print("\n📌 INSTRUKCJA:")
    print("  • SPACJA - włącz/wyłącz detekcję")
    print("  • +/- - zmień czułość")
    print("  • Q lub ESC - wyjście")
    print("\n⏳ Uruchamianie za 3 sekundy...")
    time.sleep(3)
    
    try:
        subprocess.run([sys.executable, 'enhanced_detector.py'])
    except Exception as e:
        print(f"\n❌ Błąd: {e}")
        input("\nNaciśnij Enter aby wrócić...")

def show_help():
    """Pokazuje pomoc"""
    clear_screen()
    print("\n📚 POMOC I INSTRUKCJA")
    print("="*60)
    
    help_text = """
🎯 JAK UŻYWAĆ PROGRAMU:

1. PIERWSZA INSTALACJA:
   • Wybierz opcję [1] aby zainstalować pakiety
   • Poczekaj na zakończenie instalacji

2. KONFIGURACJA:
   • Wybierz opcję [2] aby otworzyć ustawienia
   • Wybierz profil (Precyzyjny/Zbalansowany/Agresywny)
   • Dostosuj czułość według potrzeb
   • Kliknij ZAPISZ

3. URUCHOMIENIE:
   • Wybierz opcję [3] aby uruchomić detektor
   • Użyj SPACJI aby włączyć/wyłączyć
   • Użyj +/- aby zmienić czułość w locie

📋 PROFILE:
   • Precyzyjny - dla dokładnych strzałów
   • Zbalansowany - uniwersalny
   • Agresywny - szybka reakcja

⚠️  WAŻNE:
   • Uruchom jako administrator (Windows)
   • Gra powinna być w trybie okienkowym lub bez ramki
   • Wyłącz filtry graficzne w grze

🔧 ROZWIĄZYWANIE PROBLEMÓW:
   • Program się nie uruchamia → Zainstaluj pakiety [1]
   • Okno się zamyka → Uruchom jako administrator
   • Nie wykrywa → Zwiększ czułość
    """
    
    print(help_text)
    input("\nNaciśnij Enter aby wrócić...")

def main_menu():
    """Menu główne"""
    while True:
        clear_screen()
        print_header()
        
        print("\n📌 WYBIERZ OPCJĘ:\n")
        print("  [1] 📦 Zainstaluj/Sprawdź pakiety")
        print("  [2] ⚙️  Konfiguracja (ustawienia)")  
        print("  [3] 🚀 Uruchom detektor")
        print("  [4] 📚 Pomoc i instrukcja")
        print("  [5] ❌ Wyjście")
        print("\n" + "-"*60)
        
        try:
            choice = input("\n➤ Twój wybór (1-5): ").strip()
            
            if choice == '1':
                install_requirements()
            elif choice == '2':
                run_config()
            elif choice == '3':
                run_detector()
            elif choice == '4':
                show_help()
            elif choice == '5':
                print("\n👋 Do zobaczenia!")
                time.sleep(1)
                break
            else:
                print("\n⚠️  Nieprawidłowy wybór! Wybierz 1-5")
                time.sleep(1)
                
        except KeyboardInterrupt:
            print("\n\n👋 Do zobaczenia!")
            break
        except Exception as e:
            print(f"\n❌ Błąd: {e}")
            input("\nNaciśnij Enter aby kontynuować...")

def main():
    """Funkcja główna"""
    try:
        # Sprawdzenie Pythona
        if not check_python():
            input("\nNaciśnij Enter aby zakończyć...")
            return
        
        # Informacja dla Windows
        if sys.platform == 'win32':
            import ctypes
            try:
                is_admin = ctypes.windll.shell32.IsUserAnAdmin()
                if not is_admin:
                    print("\n⚠️  UWAGA: Program NIE jest uruchomiony jako administrator!")
                    print("   Niektóre funkcje mogą nie działać poprawnie.")
                    print("\n   Kliknij prawym na START.bat → Uruchom jako administrator")
                    input("\nNaciśnij Enter aby kontynuować mimo to...")
            except:
                pass
        
        # Uruchomienie menu
        main_menu()
        
    except Exception as e:
        print(f"\n❌ Krytyczny błąd: {e}")
        input("\nNaciśnij Enter aby zakończyć...")

if __name__ == "__main__":
    main()
