#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Enhanced Enemy Detector v2.0 - FIXED VERSION
Ulepszona detekcja przeciwników z pełną obsługą błędów
"""

import sys
import os
import time

# Sprawdzenie i instalacja brakujących pakietów
def check_and_install_packages():
    """Automatycznie sprawdza i instaluje brakujące pakiety"""
    import subprocess
    
    required_packages = {
        'cv2': 'opencv-python',
        'numpy': 'numpy',
        'mss': 'mss',
        'PIL': 'Pillow'
    }
    
    # Specjalne pakiety dla Windows
    if sys.platform == 'win32':
        required_packages['win32api'] = 'pywin32'
        required_packages['keyboard'] = 'keyboard'
    
    missing_packages = []
    
    for module, package in required_packages.items():
        try:
            __import__(module)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("[INFO] Instalowanie brakujących pakietów...")
        for package in missing_packages:
            print(f"  - Instalowanie {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print("[INFO] Pakiety zainstalowane!")
        print("[INFO] Restartowanie programu...")
        time.sleep(2)
        os.execv(sys.executable, ['python'] + sys.argv)

# Sprawdzenie pakietów przed importem
check_and_install_packages()

import cv2
import numpy as np
import mss
import json
from dataclasses import dataclass
from typing import Optional, Tuple, List
import math

# Import pakietów Windows jeśli dostępne
try:
    import win32api
    import win32con
    import keyboard
    WINDOWS_MODE = True
except ImportError:
    WINDOWS_MODE = False
    print("[WARNING] Tryb Windows niedostępny - niektóre funkcje będą ograniczone")

@dataclass
class DetectionConfig:
    """Konfiguracja detekcji przeciwników"""
    sensitivity: float = 0.75
    confidence_threshold: float = 0.6
    smooth_factor: float = 0.3
    fov_x: int = 120
    fov_y: int = 120
    aim_speed: float = 1.5
    prediction_factor: float = 0.2
    color_tolerance: int = 40
    head_offset: float = 0.15
    distance_weight: float = 0.7
    movement_threshold: float = 2.0

class SimpleDetector:
    """Uproszczony detektor dla trybu demonstracyjnego"""
    
    def __init__(self, config: DetectionConfig):
        self.config = config
        self.sct = mss.mss()
        self.running = False
        self.enabled = False
        
        # Ustawienia monitora
        monitor = self.sct.monitors[1]
        self.screen_width = monitor['width']
        self.screen_height = monitor['height']
        self.center_x = self.screen_width // 2
        self.center_y = self.screen_height // 2
        
        # Region skanowania
        self.update_scan_region()
        
        print("\n" + "="*60)
        print("   ENHANCED ENEMY DETECTOR V2.0 - TRYB DEMONSTRACYJNY")
        print("="*60)
        print("\nDetektor uruchomiony w trybie demonstracyjnym")
        print("Pokazuje przykładowe wykrywanie obiektów na ekranie\n")
    
    def update_scan_region(self):
        """Aktualizuje region skanowania"""
        self.scan_region = {
            'top': max(0, self.center_y - self.config.fov_y),
            'left': max(0, self.center_x - self.config.fov_x),
            'width': min(self.config.fov_x * 2, self.screen_width),
            'height': min(self.config.fov_y * 2, self.screen_height)
        }
    
    def detect_objects(self, frame: np.ndarray) -> List[dict]:
        """Wykrywa obiekty w ramce (tryb demo)"""
        objects = []
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
        # Przykładowa detekcja czerwonych obiektów
        lower_red = np.array([0, 50, 50])
        upper_red = np.array([10, 255, 255])
        mask = cv2.inRange(hsv, lower_red, upper_red)
        
        # Znajdowanie konturów
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < 500:
                continue
            
            x, y, w, h = cv2.boundingRect(contour)
            cx = x + w // 2
            cy = y + h // 2
            
            objects.append({
                'bbox': (x, y, w, h),
                'center': (cx, cy),
                'area': area,
                'type': 'czerwony_obiekt'
            })
        
        return objects
    
    def draw_overlay(self, frame: np.ndarray, objects: List[dict]) -> np.ndarray:
        """Rysuje overlay z informacjami"""
        overlay = frame.copy()
        
        # Rysowanie wykrytych obiektów
        for obj in objects:
            x, y, w, h = obj['bbox']
            cv2.rectangle(overlay, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(overlay, obj['type'], (x, y - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        
        # Status
        status_color = (0, 255, 0) if self.enabled else (0, 0, 255)
        status_text = "AKTYWNY" if self.enabled else "NIEAKTYWNY"
        cv2.putText(overlay, f"Status: {status_text}", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, status_color, 2)
        
        # Instrukcje
        instructions = [
            "Q - Wyjscie",
            "SPACE - Wlacz/wylacz",
            "+/- Czulosc"
        ]
        
        for i, inst in enumerate(instructions):
            cv2.putText(overlay, inst, (10, 60 + i * 20),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Czułość
        cv2.putText(overlay, f"Czulosc: {self.config.sensitivity:.2f}", (10, 120),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        return overlay
    
    def run(self):
        """Główna pętla programu"""
        self.running = True
        
        # Utworzenie okna
        window_name = 'Enemy Detector - Demo'
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, 800, 600)
        
        print("[INFO] Okno detektora otwarte")
        print("[INFO] Klawisze:")
        print("  - SPACJA: Włącz/wyłącz detekcję")
        print("  - +/-: Zmień czułość")
        print("  - Q lub ESC: Wyjście\n")
        
        while self.running:
            try:
                # Przechwycenie ekranu
                screenshot = self.sct.grab(self.scan_region)
                frame = np.array(screenshot)
                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
                
                # Detekcja obiektów
                objects = []
                if self.enabled:
                    objects = self.detect_objects(frame)
                
                # Rysowanie overlay
                display_frame = self.draw_overlay(frame, objects)
                
                # Zmiana rozmiaru dla lepszego wyświetlania
                display_frame = cv2.resize(display_frame, (800, 600))
                
                # Wyświetlanie
                cv2.imshow(window_name, display_frame)
                
                # Obsługa klawiszy
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q') or key == 27:  # Q lub ESC
                    break
                elif key == ord(' '):  # Spacja
                    self.enabled = not self.enabled
                    status = "włączona" if self.enabled else "wyłączona"
                    print(f"[INFO] Detekcja {status}")
                elif key == ord('+') or key == ord('='):
                    self.config.sensitivity = min(1.0, self.config.sensitivity + 0.05)
                    print(f"[INFO] Czułość: {self.config.sensitivity:.2f}")
                elif key == ord('-'):
                    self.config.sensitivity = max(0.1, self.config.sensitivity - 0.05)
                    print(f"[INFO] Czułość: {self.config.sensitivity:.2f}")
                
            except Exception as e:
                print(f"[ERROR] Błąd w pętli głównej: {e}")
                break
        
        cv2.destroyAllWindows()
        print("\n[INFO] Detektor zatrzymany.")

def main():
    """Funkcja główna"""
    print("\n" + "="*60)
    print("   ENHANCED ENEMY DETECTOR V2.0")
    print("="*60)
    
    try:
        # Ładowanie konfiguracji
        config = DetectionConfig()
        
        if os.path.exists('detector_config.json'):
            try:
                with open('detector_config.json', 'r') as f:
                    config_data = json.load(f)
                    for key, value in config_data.items():
                        if hasattr(config, key):
                            setattr(config, key, value)
                print("[INFO] Konfiguracja załadowana z pliku")
            except Exception as e:
                print(f"[WARNING] Nie można załadować konfiguracji: {e}")
                print("[INFO] Używam domyślnych ustawień")
        
        # Uruchomienie detektora
        detector = SimpleDetector(config)
        detector.run()
        
    except KeyboardInterrupt:
        print("\n[INFO] Przerwano przez użytkownika")
    except Exception as e:
        print(f"[ERROR] Wystąpił błąd: {e}")
        print("\n[INFO] Naciśnij Enter aby zakończyć...")
        input()

if __name__ == "__main__":
    main()
