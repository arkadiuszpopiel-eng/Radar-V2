# 🎮 Enemy Detector V2.0 - Instrukcja

## 📌 SZYBKI START (dla początkujących)

### 1️⃣ PIERWSZA INSTALACJA:
1. **Kliknij dwukrotnie na `INSTALUJ.bat`**
   - Poczekaj aż instalacja się zakończy
   - Jeśli pojawi się błąd, uruchom jako administrator

### 2️⃣ URUCHOMIENIE PROGRAMU:
1. **Kliknij dwukrotnie na `START.bat`**
   - Wybierz odpowiednią opcję z menu
   - Zalecamy zacząć od opcji [2] Konfiguracja

### 3️⃣ JAK UŻYWAĆ:
1. **Najpierw skonfiguruj** (opcja 2 w menu)
   - Wybierz profil: Zbalansowany (dla początkujących)
   - Kliknij ZAPISZ
2. **Uruchom detektor** (opcja 3 w menu)
   - Naciśnij SPACJĘ aby włączyć/wyłączyć
   - Użyj + i - aby zmienić czułość

---

## ⚙️ PROFILE USTAWIEŃ

### 🎯 **Precyzyjny**
- Dla graczy preferujących dokładność
- Wolniejsze, ale pewniejsze celowanie
- Idealne dla snajperów

### ⚖️ **Zbalansowany** (ZALECANY)
- Uniwersalne ustawienia
- Dobre dla większości sytuacji
- Najlepsze dla początkujących

### ⚔️ **Agresywny**
- Szybkie reakcje
- Dla dynamicznej gry
- Może mieć więcej błędnych detekcji

---

## 🔧 ROZWIĄZYWANIE PROBLEMÓW

### ❌ Program się nie uruchamia
1. Uruchom `INSTALUJ.bat` jako administrator
2. Upewnij się, że masz Python 3.6+
3. Sprawdź czy Windows Defender nie blokuje

### ❌ Okno się od razu zamyka
1. Uruchom `START.bat` jako administrator
2. Otwórz CMD i wpisz: `python launcher.py`
3. Zobacz jaki błąd się pokazuje

### ❌ Nie wykrywa przeciwników
1. Zwiększ czułość (klawisz +)
2. Zmień profil na Agresywny
3. Upewnij się, że gra jest widoczna

### ❌ Za dużo fałszywych detekcji
1. Zmniejsz czułość (klawisz -)
2. Zmień profil na Precyzyjny
3. Zmniejsz FOV w konfiguracji

---

## 📋 PLIKI W PAKIECIE

| Plik | Opis |
|------|------|
| **START.bat** | 🚀 Główne uruchomienie programu |
| **INSTALUJ.bat** | 🔧 Instalator wymagań |
| **launcher.py** | 📱 Menu główne |
| **config_gui.py** | ⚙️ Ustawienia graficzne |
| **enhanced_detector.py** | 🎮 Główny program |
| **detector_config.json** | 💾 Zapisane ustawienia |

---

## ⌨️ SKRÓTY KLAWISZOWE

W detektorze:
- **SPACJA** - włącz/wyłącz
- **+** - zwiększ czułość
- **-** - zmniejsz czułość
- **Q** lub **ESC** - wyjście

---

## 💡 WSKAZÓWKI

1. **Zacznij od profilu Zbalansowany**
2. **Uruchom jako administrator** dla najlepszych efektów
3. **Gra powinna być w oknie** lub trybie bez ramki
4. **Wyłącz filtry graficzne** w grze
5. **Dostosuj czułość** do swojego stylu gry

---

## ⚠️ WAŻNE INFORMACJE

- Program działa **tylko lokalnie** na Twoim komputerze
- **Nie modyfikuje** plików gry
- **Nie łączy się** z internetem
- Wszystkie dane są **bezpieczne i prywatne**

---

## 📞 POMOC

Jeśli masz problemy:
1. Przeczytaj rozdział "Rozwiązywanie problemów" powyżej
2. Upewnij się, że masz wszystkie pliki
3. Uruchom jako administrator
4. Sprawdź wersję Python (powinna być 3.6+)

---

## 🎯 PIERWSZE URUCHOMIENIE - KROK PO KROKU

1. **Rozpakuj wszystkie pliki** do jednego folderu
2. **Kliknij `INSTALUJ.bat`** (tylko raz, przy pierwszym użyciu)
3. **Kliknij `START.bat`**
4. **Wybierz [2] Konfiguracja**
5. **Wybierz profil "Zbalansowany"**
6. **Kliknij "ZAPISZ"**
7. **Kliknij "URUCHOM DETEKTOR"**
8. **Gotowe! Użyj SPACJI aby włączyć**

---

*Enemy Detector V2.0 - Prosty i przyjazny dla każdego użytkownika*
